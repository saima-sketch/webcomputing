// =============================================
// Calculator Application
// Author: [Shah Saima]
// Description: Professional CLI Calculator
// =============================================

const readline = require('readline');

// ANSI color codes for terminal formatting
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m'
};

// Create readline interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

/**
 * Promisified question function for easier async/await usage
 */
function question(prompt) {
    return new Promise((resolve) => {
        rl.question(prompt, resolve);
    });
}

/**
 * Displays a formatted header for the calculator
 */
function displayHeader() {
    console.log(`\n${colors.cyan}${'='.repeat(50)}${colors.reset}`);
    console.log(`${colors.bright}${colors.magenta}           PROFESSIONAL CALCULATOR${colors.reset}`);
    console.log(`${colors.cyan}${'='.repeat(50)}${colors.reset}`);
    console.log(`${colors.yellow}Supported operations: +, -, *, /${colors.reset}`);
    console.log(`${colors.cyan}${'-'.repeat(50)}${colors.reset}\n`);
}

/**
 * Validates if input is a valid number
 */
function isValidNumber(input) {
    return !isNaN(parseFloat(input)) && isFinite(input);
}

/**
 * Validates if operator is supported
 */
function isValidOperator(operator) {
    return ['+', '-', '*', '/'].includes(operator);
}

/**
 * Performs the calculation based on operator
 */
function calculate(num1, num2, operator) {
    const a = parseFloat(num1);
    const b = parseFloat(num2);
    
    switch (operator) {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
        case '/':
            if (b === 0) {
                throw new Error('Division by zero is not allowed');
            }
            return a / b;
        default:
            throw new Error('Invalid operator');
    }
}

/**
 * Displays the result in a formatted box
 */
function displayResult(num1, num2, operator, result) {
    const calculation = `${num1} ${operator} ${num2}`;
    
    console.log(`\n${colors.green}${'═'.repeat(50)}${colors.reset}`);
    console.log(`${colors.bright}${colors.blue}                CALCULATION RESULT${colors.reset}`);
    console.log(`${colors.green}${'═'.repeat(50)}${colors.reset}`);
    console.log(`${colors.white}Operation:${colors.reset} ${colors.yellow}${calculation}${colors.reset}`);
    console.log(`${colors.white}Result:${colors.reset}   ${colors.bright}${colors.green}${result}${colors.reset}`);
    console.log(`${colors.green}${'═'.repeat(50)}${colors.reset}\n`);
}

/**
 * Displays error messages in red
 */
function displayError(message) {
    console.log(`\n${colors.red}${'⚠'.repeat(10)} ERROR ${'⚠'.repeat(10)}${colors.reset}`);
    console.log(`${colors.red}${message}${colors.reset}`);
    console.log(`${colors.red}${'⚠'.repeat(26)}${colors.reset}\n`);
}

/**
 * Asks user if they want to perform another calculation
 */
async function askToContinue() {
    const answer = await question(`${colors.cyan}Would you like to perform another calculation? (y/n): ${colors.reset}`);
    return answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes';
}

/**
 * Main calculator function
 */
async function runCalculator() {
    try {
        displayHeader();
        
        // Get first number
        let num1 = await question(`${colors.blue}Enter the first number: ${colors.reset}`);
        while (!isValidNumber(num1)) {
            displayError('Please enter a valid number');
            num1 = await question(`${colors.blue}Enter the first number: ${colors.reset}`);
        }
        
        // Get operator
        let operator = await question(`${colors.blue}Enter the operator (+, -, *, /): ${colors.reset}`);
        while (!isValidOperator(operator)) {
            displayError('Please enter a valid operator (+, -, *, /)');
            operator = await question(`${colors.blue}Enter the operator (+, -, *, /): ${colors.reset}`);
        }
        
        // Get second number
        let num2 = await question(`${colors.blue}Enter the second number: ${colors.reset}`);
        while (!isValidNumber(num2)) {
            displayError('Please enter a valid number');
            num2 = await question(`${colors.blue}Enter the second number: ${colors.reset}`);
        }
        
        // Perform calculation and display result
        try {
            const result = calculate(num1, num2, operator);
            displayResult(num1, num2, operator, result);
        } catch (calcError) {
            displayError(calcError.message);
        }
        
        // Ask if user wants to continue
        const continueCalc = await askToContinue();
        if (continueCalc) {
            console.log(); // Add empty line for better spacing
            await runCalculator();
        } else {
            console.log(`\n${colors.magenta}Thank you for using the Professional Calculator!${colors.reset}`);
            rl.close();
        }
        
    } catch (error) {
        displayError('An unexpected error occurred: ' + error.message);
        rl.close();
    }
}

/**
 * Graceful shutdown handler
 */
function setupShutdownHandler() {
    rl.on('close', () => {
        console.log(`\n${colors.cyan}Calculator application closed.${colors.reset}`);
        process.exit(0);
    });
    
    process.on('SIGINT', () => {
        console.log(`\n\n${colors.yellow}Calculator interrupted by user. Goodbye!${colors.reset}`);
        rl.close();
    });
}

// Start the application
if (require.main === module) {
    setupShutdownHandler();
    runCalculator();
}

module.exports = {
    calculate,
    isValidNumber,
    isValidOperator
};